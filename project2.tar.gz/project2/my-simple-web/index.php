<?php
echo "Welcome to MySimpleWeb.<br>";
echo gethostname(), "<br>";

echo "This is index.php file.";
?>
